define({
  root: ({
    _widgetLabel: "Edit Table"
  })
});
